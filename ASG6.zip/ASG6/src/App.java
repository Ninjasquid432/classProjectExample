import controller.NavDocController;
import model.NavigableDocModel;
import view.NavDocView;

public class App {
    public static void main(String[] args) {
        NavigableDocModel<String> model = new NavigableDocModel<>();
        NavDocView view = new NavDocView();

        NavDocController controller = new NavDocController(view, model);
        view.setVisible(true);
    }
}