package model;

import java.util.List;

public class NavigableDocModel <T>{
    private Node<T> firstLeft;
    private Node<T> firstRight;
    private int numOfNodesL;
    private int numOfNodesR;

    public NavigableDocModel(){
        this.firstLeft = null;
        this.firstRight = null;
        this.numOfNodesR = 0;
        this.numOfNodesL = 0;
    }

    /**
     * The insertNewItemRt method retuns nothing and takes an item
     * of type T and adds it to the front of the right side
     * @param item --> the desired object to be added to the node.
     */
    //runtime is O(1)
    public void insertNewItemRt(T item){
        if(firstRight == null){
            Node<T> newNode = new Node<>(item, null);
            firstRight = newNode;
        } else{
            Node<T> newNode = new Node<>(item, firstRight);
            firstRight = newNode;
        }
        numOfNodesR++;
    }

    //frwd method throws new illegal state exception
    // run time of O(n)
    public void forward(){
        if(firstRight == null){
            throw new IllegalStateException("nothing on right side...");
        }
        // we want to find the last node in the left list
        if(firstLeft == null){
            //no nodes in left chain
            Node<T> nn = new Node<>(firstRight.data, null);
            firstLeft = nn;

            firstRight = firstRight.next; // garbage collector remove old node
        }else{
            //some number of nodes in left chain
            Node<T> curr = firstLeft;

            while(curr.next != null){
                curr = curr.next;
            }

            Node<T> nn = new Node<>(firstRight.data, null);
            curr.next = nn;

            firstRight = firstRight.next;
        }
        numOfNodesR--;
        numOfNodesL++;
    }

    //O(1)
    public int lenBeforeBar(){
       return numOfNodesL;
    }

    //O(1)
    public int lenAfterBar(){
        return numOfNodesR;
    }

    //takes everything from the left and adds to the right
    //O(n)
    public void reset(){
        if(firstLeft == null){
            return; //notjing in left side
        }
        //1 find the last node in left chain
        Node<T> curr = firstLeft;

        while(curr.next != null){
            curr = curr.next;
        }
        //2. make the next of curr point to first right
        curr.next = firstRight;
        //3. make the first right point to the first left
        firstRight = firstLeft;
        //4. first left point to null
        firstLeft = null;
    }

    //    O(n)
    //helper method
    public Pair<Side, Integer> contains(T item, int curr, Pair<Side,Integer> total,
                                        Node<T> leftCurr, Node<T> rightCurr){

        int totalSum = numOfNodesL + numOfNodesR;


        if(curr > totalSum -1){
            return total;
        }

        if (rightCurr.data.equals(item)){
            total = new Pair<>(Side.RIGHT, curr - numOfNodesL);
            return total;
        }

        if(curr < numOfNodesL){
            if(leftCurr.data.equals(item)){
                total = new Pair<>(Side.LEFT, curr);

                if(rightCurr.data.equals(item)){
                    total = new Pair<>(Side.BOTH, curr);
                    return total;

                }if(rightCurr.next == null){
                    return total;
                }
                return contains(item, curr, total, leftCurr, rightCurr.next);
            }
            return contains(item, curr +1, total, leftCurr.next, rightCurr);
        }

        return contains(item, curr+1, total, leftCurr, rightCurr.next);

    }
    //contains takes an item of type t and returns a pair<side, integer)
    //kick off method
    //O(1)
    public Pair<Side, Integer> contains(T item){
        Pair<Side, Integer> total = new Pair<>(Side.NONE, -1);
        return contains(item, 0, total, firstLeft, firstRight);
    }


    //runtime is O(n)
    @Override
    public String toString() {
        String str = "";

        Node<T> currL = firstLeft;
        Node<T> currR = firstRight;


        while (currL != null) {
            str = str + currL.data + " ";
            currL = currL.next; // advances the curr on left to next node
        }


        str += "$ ";

        while (currR != null) {
            str = str + currR.data + " ";
            currR = currR.next;
        }

        return str;
    }
}
