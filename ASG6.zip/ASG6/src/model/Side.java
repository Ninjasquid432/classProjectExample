package model;

public enum Side {
    LEFT,
    RIGHT,
    BOTH,
    NONE
}
