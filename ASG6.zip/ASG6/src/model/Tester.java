package model;

public class Tester {
    public static void main(String[] args) {
        NavigableDocModel<String> data = new NavigableDocModel<>();

        data.insertNewItemRt("a");
        data.insertNewItemRt("b");
        data.insertNewItemRt("c");

        System.out.println(data);

       System.out.println(data);
       System.out.println(data.contains("a"));

    }
}
