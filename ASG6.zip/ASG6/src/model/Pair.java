package model;

public class Pair<T1, T2> {
    public T1 first;
    public T2 second;

    public Pair(T1 field1, T2 field2){
        this.first = field1;
        this.second = field2;
    }

    @Override
    public String toString() {
        String result = "";
        result += "it appears on " + first.toString() + " at index " + second.toString();
        return result;
    }
}
