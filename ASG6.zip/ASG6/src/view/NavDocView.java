package view;

import javax.swing.*;

public class NavDocView extends JFrame {

    //field
    public NavDocForm form;

    //class constructor
    public NavDocView(){
        this.form = new NavDocForm();

        JPanel content = form.getMyPanel();
        this.setContentPane(content);

        this.setTitle("My list");
        this.pack();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
