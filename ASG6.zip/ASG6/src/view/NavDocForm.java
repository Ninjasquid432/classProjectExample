package view;

import javax.swing.*;

public class NavDocForm {
    private JPanel myPanel;
    private JTextField navDocsContent;
    private JButton addButton;
    private JButton resetButton;
    private JButton forwardButton;
    private JButton containsButton;
    private JTextField addTextField;

    public JTextField getAddTextField() {
        return addTextField;
    }

    public JPanel getMyPanel() {
        return myPanel;
    }

    public JTextField getNavDocsContent() {
        return navDocsContent;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getResetButton() {
        return resetButton;
    }

    public JButton getForwardButton() {
        return forwardButton;
    }

    public JButton getContainsButton() {
        return containsButton;
    }
}
